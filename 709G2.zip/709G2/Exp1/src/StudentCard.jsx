import React from 'react'

function StudentCard({ studentdata }) {

    return (
        <div>
            <p></p>
        </div>
    )
}

export default StudentCard